"""
Shared modules for AWS Lambda Architecture
"""
